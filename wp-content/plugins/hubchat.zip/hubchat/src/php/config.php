<?php

$hubchatHost = getenv('HUBCHAT_HOST');

$config = array(
    'hubchatHost' => $hubchatHost ?: 'https://www.hubchat.com'
);
