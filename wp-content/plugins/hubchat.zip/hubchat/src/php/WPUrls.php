<?php namespace Hubchat\WordPressPlugin;

class WPUrls
{
    public function getDiscussionSettingsUrl()
    {
        return get_admin_url(null, 'options-discussion.php');
    }
}
