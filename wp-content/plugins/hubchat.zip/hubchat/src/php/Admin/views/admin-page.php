<div>
    <iframe
        src="<?php echo $iframeUrl; ?>"
        style="width: 100%; height: 750px;"
        class="hubchat-admin-iframe">
    </iframe>
</div>
