<span
    class="hubchat-comment-count"
    data-forum-slug="<?php echo $communitySlug; ?>"
    data-embedded-id="<?php echo $embeddedId; ?>">
</span>
