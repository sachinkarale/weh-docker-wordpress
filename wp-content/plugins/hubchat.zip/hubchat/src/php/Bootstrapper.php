<?php namespace Hubchat\WordPressPlugin;

class Bootstrapper
{
    public function __construct(
        $adminBootstrapper,
        $commentingBootstrapper,
        $communitySlugUpdateApi,
        $hubchatOptions
    ) {
        $this->hubchatOptions = $hubchatOptions;
        $this->adminBootstrapper = $adminBootstrapper;
        $this->commentingBootstrapper = $commentingBootstrapper;
        $this->communitySlugUpdateApi = $communitySlugUpdateApi;
    }

    public function bootstrap()
    {
        $this->communitySlugUpdateApi->bootstrap();
        $communitySlug = $this->hubchatOptions->getCommunitySlug();

        if (is_admin()) {
            $this->adminBootstrapper->bootstrap();
        } elseif (!empty($communitySlug)) {
            $this->commentingBootstrapper->bootstrap();
        }
    }
}
