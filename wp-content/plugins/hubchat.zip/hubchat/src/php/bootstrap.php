<?php namespace Hubchat\WordPressPlugin;

function bootstrap()
{
    require 'config.php';

    $pluginRootPath = dirname(dirname(__DIR__)) . '/';
    $pluginBasename = plugin_basename("{$pluginRootPath}hubchat.php");
    $pluginRootUrl = plugin_dir_url("{$pluginRootPath}hubchat.php");

    // Create a nonce (CSRF token) with this name and require
    // all community slug update requests to include that.
    $nonceName = 'hubchat-community-slug-update';

    $hubchatOptions = new HubchatOptions();

    $commentCountView = new View(__DIR__ . '/Commenting/views/comment-count.php');
    $commentingBootstrapper = new Commenting\Bootstrapper(
        $commentCountView,
        $hubchatOptions,
        $config['hubchatHost'] . '/embedded/public/js/incl/plugins.js'
    );

    $adminIframeUrl = new Admin\IframeUrl($config['hubchatHost'], site_url(), 'rgb(241,241,241)');
    $adminScriptUrl = "{$pluginRootUrl}dist/admin.js";
    $adminStyleUrl = "{$pluginRootUrl}src/styles/admin-style.css";
    $adminIconUrl = "{$pluginRootUrl}src/images/menu-icon.png";
    $adminPageView = new View(__DIR__ . "/Admin/views/admin-page.php");
    $adminController = new Admin\Controller(
        $adminIframeUrl,
        $adminPageView,
        $hubchatOptions
    );
    $setupNoticeView = new View(__DIR__ . "/Admin/views/setup-notice.php");
    $discussionSettingsNoticeView = new View(__DIR__ . "/Admin/views/discussion-settings-notice.php");
    $adminNoticeController = new Admin\NoticeController(
        $hubchatOptions,
        $setupNoticeView,
        $discussionSettingsNoticeView
    );
    $adminBootstrapper = new Admin\Bootstrapper(
        $pluginBasename,
        $adminScriptUrl,
        $adminStyleUrl,
        $adminIconUrl,
        $config['hubchatHost'],
        $nonceName,
        $adminController,
        $adminNoticeController
    );

    $router = new WPAjaxRouter();
    $communitySlugUpdateApi = new CommunitySlugUpdateApi(
        $hubchatOptions,
        $router,
        $nonceName
    );

    $bootstrapper = new Bootstrapper(
        $adminBootstrapper,
        $commentingBootstrapper,
        $communitySlugUpdateApi,
        $hubchatOptions
    );
    $bootstrapper->bootstrap();
}
