<?php

/*
Plugin Name: Hubchat
Description: Add Hubchat comments to posts
Version:     1.0.0
Author:      Hubchat
Author URI:  http://www.hubchat.com/
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

require 'vendor/autoload.php';
require 'src/php/bootstrap.php';

Hubchat\WordPressPlugin\bootstrap();
