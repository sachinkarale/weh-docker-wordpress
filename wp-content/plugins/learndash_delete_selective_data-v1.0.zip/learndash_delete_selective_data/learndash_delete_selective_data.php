<?php
/**
 * @package LearnDash Delete Specific Data
 * @version 1.0 
 */
/*
Plugin Name: LearnDash  Delete Specific Data
Description:  LearnDash  Delete Specific Data
Version: 1.0
Author: Next Software Solutions Pvt Ltd
Author URI: https://www.nextsoftwaresolutions.com
*/

	function learndash_specific_delete_user_data_init() {
		if(isset($_GET["page"]) && $_GET["page"] == "learndash_specific_delete_user_data_page" && !empty($_POST["learndash_specific_delete_user_data_user_id"])) { 
			learndash_specific_delete_user_data($_POST["learndash_specific_delete_user_data_user_id"]);
		}
	}
	add_action("init", "learndash_specific_delete_user_data_init");
	function learndash_specific_delete_user_data_options($user) {
		$courses = get_posts(array('post_type' => 'sfwd-courses', 'posts_per_page' => -1));	
		$lessons = get_posts(array('post_type' => 'sfwd-lessons', 'posts_per_page' => -1));	
		$topics = get_posts(array('post_type' => 'sfwd-topic', 'posts_per_page' => -1));	
		$quizzes = get_posts(array('post_type' => 'sfwd-quiz', 'posts_per_page' => -1));	

		if(!current_user_can('manage_options') && !learndash_specific_is_group_leader($user->ID))
			return "";
		?>
		<div id="learndash_specific_delete_user_course_data">
		<h2><?php _e('Permanently Delete Specific Course Data', 'learndash'); ?></h2>
		<select name="learndash_specific_delete_user_course_data">
			<option value="0"><?php _e("-- Select --", "learndash"); ?></option>
			<?php learndash_specific_show_options($courses); ?>
		</select>
		<?php _e('<strong>This cannot be undone.</strong>', 'learndash'); ?><br><br>
		</div>
		<div id="learndash_specific_delete_user_lesson_data">
		<h2><?php _e('Permanently Delete Specific Lesson Data', 'learndash'); ?></h2>
		<select name="learndash_specific_delete_user_lesson_data">
			<option value="0"><?php _e("-- Select --", "learndash"); ?></option>
			<?php learndash_specific_show_options($lessons); ?>
		</select>
		<?php _e('<strong>This cannot be undone.</strong>', 'learndash'); ?><br><br>
		</div>
		<div id="learndash_specific_delete_user_quiz_data">
		<h2><?php _e('Permanently Delete Specific Quiz Data', 'learndash'); ?></h2>
		<select name="learndash_specific_delete_user_quiz_data">
			<option value="0"><?php _e("-- Select --", "learndash"); ?></option>
			<?php learndash_specific_show_options($quizzes); ?>
		</select>
		<?php _e('<strong>This cannot be undone.</strong>', 'learndash'); ?><br><br>
		</div>
		<div id="learndash_specific_delete_user_topic_data">
		<h2><?php _e('Permanently Delete Specific Topic Data', 'learndash'); ?></h2>
		<select name="learndash_specific_delete_user_topic_data">
			<option value="0"><?php _e("-- Select --", "learndash"); ?></option>
			<?php learndash_specific_show_options($topics); ?>
		</select>
		<input type="hidden" name="learndash_specific_delete_user_data_user_id" value="<?php echo $user->ID; ?>"/>
		<?php _e('<strong>This cannot be undone.</strong>', 'learndash'); ?><br><br>
		</div>
		<?php	
	}
    add_action( 'show_user_profile', 'learndash_specific_delete_user_data_options',1000,1 );
    add_action( 'edit_user_profile', 'learndash_specific_delete_user_data_options',1000,1 );

    function learndash_specific_show_options($posts) {
            if(!empty($posts))
            foreach($posts as $post) {
            	echo "<option value='".$post->ID."'>".$post->post_title."</option>";
            }
    }
    function learndash_specific_is_group_leader($user_id) {
    	$current_user_id = get_current_user_id();

    	if(!is_group_leader($current_user_id) || !learndash_specific_is_group_leader_of_user($current_user_id, $user_id))
    		return false;
    	else
    		return true;
    }
	function learndash_specific_delete_user_data($user_id) { 
		if(!current_user_can('manage_options') && !learndash_specific_is_group_leader($user_id))
			return;
 //echo 'a<pre>';print_r($_GET);print_r($_POST);
		$user = get_user_by("id", $user_id);
		if(empty($user->ID) || $user->ID != $_POST["learndash_specific_delete_user_data_user_id"])
			return; //echo 'a';

		if(!empty($_POST['learndash_specific_delete_user_course_data'])) {
			$course_id = $_POST['learndash_specific_delete_user_course_data'];
 //echo 'a';
			global $wpdb;
			$usermeta = get_user_meta($user_id, "_sfwd-course_progress", true);
//print_r($usermeta);
			if(isset($usermeta[$course_id]))
			{
				unset($usermeta[$course_id]);
				update_user_meta($user_id, "_sfwd-course_progress", $usermeta);
			}
		}
		if(!empty($_POST['learndash_specific_delete_user_lesson_data'])) {
			$lesson_id = $_POST['learndash_specific_delete_user_lesson_data'];
			learndash_specific_mark_lesson_incomplete($user_id, $lesson_id);
		}
		if(!empty($_POST['learndash_specific_delete_user_topic_data'])) {
			$topic_id = $_POST['learndash_specific_delete_user_topic_data'];
			learndash_specific_mark_topic_incomplete($user_id, $topic_id);
		}
		if(!empty($_POST['learndash_specific_delete_user_quiz_data'])) {
			$quiz_id = $_POST['learndash_specific_delete_user_quiz_data'];
			learndash_specific_quiz_data($user_id, $quiz_id);
		}		
	}
	function learndash_specific_mark_lesson_incomplete($user_id, $lesson_id) {//echo "learndash_specific_mark_lesson_incomplete($user_id, $lesson_id)";
		global $wpdb;
		$usermeta = get_user_meta($user_id, "_sfwd-course_progress", true);

		if(!empty($usermeta))
		foreach ($usermeta as $key => $course_data) {
			if(isset($usermeta[$key]["lessons"][$lesson_id]))
			{
				unset($usermeta[$key]["lessons"][$lesson_id]);
				$usermeta[$key]["completed"] = count($usermeta[$key]["lessons"]);
				update_user_meta($user_id, "_sfwd-course_progress", $usermeta);
			}
		}		
	}
	function learndash_specific_mark_topic_incomplete($user_id, $topic_id) { //echo "learndash_specific_mark_topic_incomplete($user_id, $lesson_id)";
		global $wpdb;
		$usermeta = get_user_meta($user_id, "_sfwd-course_progress", true);
		$lesson_id = learndash_get_setting($topic_id, "lesson");
		if(empty($lesson_id) || empty($usermeta))
			return;
		foreach ($usermeta as $key => $course_data) {
			if(isset($usermeta[$key]["topics"][$lesson_id][$topic_id]))
			{
				unset($usermeta[$key]["topics"][$lesson_id][$topic_id]);
				unset($usermeta[$key]["lessons"][$lesson_id]);
				$usermeta[$key]["completed"] = count($usermeta[$key]["lessons"]);
				update_user_meta($user_id, "_sfwd-course_progress", $usermeta);
			}
		}		
	}
	function learndash_specific_quiz_data($user_id, $quiz_id) {
		global $wpdb;
//		echo "quiz data<pre>";
		//Clear User Meta
		$usermeta = get_user_meta($user_id, "_sfwd-quizzes", true);
//print_r($usermeta);
		if(!empty($usermeta) && is_array($usermeta)) {
			foreach ($usermeta as $key => $quizmeta) {
				if($quizmeta["quiz"] != $quiz_id)
					$usermeta_new[] = $quizmeta;
			}
			update_user_meta($user_id, "_sfwd-quizzes", $usermeta_new);
		}
//print_r($usermeta_new);
		//Lesson/Topic
		$lesson_id = learndash_get_setting($quiz_id, "lesson");
		if(!empty($lesson_id)) {
			$lesson_post = get_post($lesson_id);
			if($lesson_post->post_type == "sfwd-lessons")
				learndash_specific_mark_lesson_incomplete($user_id, $lesson_id);
			else if($lesson_post->post_type == "sfwd-topic")
				learndash_specific_mark_topic_incomplete($user_id, $lesson_id);
		}

		//Pro Quiz Data
		$pro_quiz_id = learndash_get_setting($quiz_id, "quiz_pro");
//echo $pro_quiz_id;
		$ref_ids = $wpdb->get_col($wpdb->prepare("SELECT statistic_ref_id FROM ".$wpdb->prefix."wp_pro_quiz_statistic_ref WHERE  user_id = '%d' AND quiz_id = '%d' ", $user_id, $pro_quiz_id));
//print_r($ref_ids);
		if(!empty($ref_ids[0])) {
			$wpdb->delete($wpdb->prefix."wp_pro_quiz_statistic_ref", array('user_id' => $user_id, 'quiz_id' => $pro_quiz_id));
			$wpdb->query("DELETE FROM ".$wpdb->prefix."wp_pro_quiz_statistic WHERE statistic_ref_id IN (".implode(",", $ref_ids).")");
		}

		//$wpdb->query("DELETE FROM ".$wpdb->usermeta." WHERE meta_key LIKE 'completed_%' AND user_id = '".$user->ID."'");
		$wpdb->delete($wpdb->prefix."wp_pro_quiz_toplist",  array('user_id' => $user_id, 'quiz_id' => $pro_quiz_id));
	}
    add_action( 'personal_options_update', 'learndash_specific_delete_user_data' );
    add_action( 'edit_user_profile_update', 'learndash_specific_delete_user_data' );




	add_action('admin_menu', 'learndash_specific_delete_user_data_menu', 1);
	function learndash_specific_delete_user_data_menu() {
		add_submenu_page("edit.php?post_type=sfwd-courses", __("Delete User Data","learndash"), __("Delete User Data","learndash") ,'group_leader','learndash_specific_delete_user_data_page', 'learndash_specific_delete_user_data_page');
	}

	function learndash_specific_submenu($add_submenu) {
		$add_submenu["learndash_specific_delete_user_data_page"] = array(
										"name" 	=>	__("Delete User Data","learndash"),
										"cap"	=>	"group_leader",
										"link"	=> 'admin.php?page=learndash_specific_delete_user_data_page'
										);
		return $add_submenu;
	}
	add_filter("learndash_submenu", "learndash_specific_submenu", 1, 1 );
	function learndash_specific_admin_tabs($admin_tabs) {
		$admin_tabs["learndash_specific_delete_user_data_page"] = array(
										"link"	=>	'admin.php?page=learndash_specific_delete_user_data_page',
										"name"	=>	__("Delete User Data","learndash"),
										"id"	=>	"toplevel_page_learndash_specific_delete_user_data_page",
										"menu_link"	=> 	"admin.php?page=group_admin_page",
									);
		return $admin_tabs;
	}
	add_filter("learndash_admin_tabs", "learndash_specific_admin_tabs", 1, 1);


	function learndash_specific_delete_user_data_page() {
	$current_user = wp_get_current_user();
	if(empty($current_user->ID) || !$current_user->has_cap("group_leader"))
		die(__("Please login as a Group Administrator", "learndash"));

	global $wpdb;
	$group_ids = learndash_get_administrators_group_ids($current_user->ID);
	
	if(!isset($_GET['group_id']) || !in_array($_GET['group_id'], $group_ids)) {
	?>
	<div class="wrap">
	<h2><?php _e("Group Administration", "learndash"); ?> : <?php _e("Delete User Data", "learndash"); ?></h2>
	
	<table cellspacing="0" class="wp-list-table widefat fixed groups_table">
	<thead>
	<tr>	
		<th class="manage-column column-sno " id="sno" scope="col"><?php _e("S. No.", 'learndash'); ?></th>
		
		<th class="manage-column column-group " id="group" scope="col"><?php _e("Group", 'learndash'); ?></th>
		
		<th class="manage-column column-action" id="action" scope="col"><?php _e("Action", 'learndash'); ?></span><span class="sorting-indicator"></span></th>
	</tr>
	</thead>
	<tfoot>
	<tr>	
		<th class="manage-column column-sno " id="sno" scope="col"><?php _e("S. No.", 'learndash'); ?></th>
		
		<th class="manage-column column-group " id="group" scope="col"><?php _e("Group", 'learndash'); ?></th>
		
		<th class="manage-column column-action" id="action" scope="col"><?php _e("Action", 'learndash'); ?></span><span class="sorting-indicator"></span></th>
	</tr>
	</tfoot>
	<tbody>
		<?php $sn = 1;
		foreach($group_ids as $group_id) {
			$group = get_post($group_id);
		?>
		<tr>
			<td><?php echo $sn++; ?></td>
			<td><?php echo $group->post_title; ?></td>
			<td><a href="<?php echo admin_url("edit.php?post_type=sfwd-courses&page=learndash_specific_delete_user_data_page&group_id=".$group_id); ?>"><?php _e("List Users", "learndash"); ?></a></td>
		</tr>
		<?php
		}
		?>
	<tbody>
	</table>
	</div>
	<?php
	}
	else
	{
		if(!isset($_GET['user_id'])) {
		$group_id = $_GET['group_id'];
		$group = get_post($group_id);
		?>
		<div class="wrap">
		<h2><?php echo __("Group Administration", "learndash"); ?>: <?php _e("Delete User Data", "learndash"); echo "<br>".$group->post_title; ?> <small>| <a href="<?php echo admin_url("edit.php?post_type=sfwd-courses&page=learndash_specific_delete_user_data_page"); ?>"><?php echo __("Back", "learndash"); ?></a></small></h2>
		<p>
			<?php echo $group->post_content; ?>
		</p>
		<?php
		echo learndash_specific_group_user_list($group_id);
		?>
		</div>
		
		<?php
		}
		else
		{
			$user_id = $_GET['user_id'];
			$group_id = $_GET['group_id'];
			$group_user_ids = learndash_get_groups_user_ids($group_id);
			$user = get_user_by("id",$user_id);
			
			?>
			<div class="wrap">
			<h2><?php echo __("Group Administration", "learndash");?> : <?php _e("Delete User Data", "learndash"); echo "<br>User: ".$user->display_name; ?> <small>| <a href="<?php echo admin_url("edit.php?post_type=sfwd-courses&page=learndash_specific_delete_user_data_page&group_id=".$group_id); ?>"><?php echo __("Back", "learndash"); ?></a></small></h2><br><br>
			<?php
			if(in_array($user_id, $group_user_ids)) {
				echo learndash_course_info_shortcode(array('user_id' => $user_id));
				?>
				<form method="post">
				<?php
				learndash_specific_delete_user_data_options($user);

				?>
				<input type="submit" value="Delete Now" class="button button-primary" />
				</form>
				<?php
			}
			?>
			</div>
			<?php
		}
	}
	
	}

function learndash_specific_group_user_list($group_id) {
	$current_user = wp_get_current_user();
	if(empty($current_user->ID) || !$current_user->has_cap("group_leader"))
		return __("Please login as a Group Administrator", "learndash");

	global $wpdb;
	$users = learndash_get_groups_user_ids($group_id);
	
	if(!empty($users))
	{
		$users = $wpdb->get_results("SELECT * FROM $wpdb->users WHERE `ID` IN (".implode(",",$users).")");
		if(!empty($users)) {
			?>
			<table cellspacing="0" class="wp-list-table widefat fixed groups_user_table">
			<thead>
			<tr>	
				<th class="manage-column column-sno " id="sno" scope="col" ><?php _e("S. No.", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Name", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Username", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Email", 'learndash'); ?></th>
				<th class="manage-column column-action" id="action" scope="col"><?php _e("Action", 'learndash'); ?></span></th>
			</tr>
			</thead>
			<tfoot>
			<tr>	
				<th class="manage-column column-sno " id="sno" scope="col" ><?php _e("S. No.", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Name", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Username", 'learndash'); ?></th>
				<th class="manage-column column-name " id="group" scope="col"><?php _e("Email", 'learndash'); ?></th>
				<th class="manage-column column-action" id="action" scope="col"><?php _e("Action", 'learndash'); ?></span></th>
			</tr>
			</tfoot>
			<tbody>
				<?php $sn = 1;
				foreach($users as $user) {
					$name = isset($user->display_name)? $user->display_name:$user->user_nicename;
				?>
				<tr>
					<td><?php echo $sn++; ?></td>
					<td><?php echo $name; ?></td>
					<td><?php echo $user->user_login; ?></td>
					<td><?php echo $user->user_email; ?></td>
					<td><a href="<?php echo admin_url("edit.php?post_type=sfwd-courses&page=learndash_specific_delete_user_data_page&group_id=".$group_id."&user_id=".$user->ID); ?>"><?php _e("Select", "learndash"); ?></a></td>
				</tr>
				<?php
				}
				?>
			</table>
		<?php
		}
	}
	else
		return __("No users.", "learndash");
}


function learndash_specific_is_group_leader_of_user($group_leader_id, $user_id) {
        $admin_groups = learndash_get_administrators_group_ids($group_leader_id);
        $has_admin_groups = !empty($admin_groups) && is_array($admin_groups) && !empty($admin_groups[0]);
        foreach ($admin_groups as $group_id) {
                $learndash_is_user_in_group = llearndash_specific_is_user_in_group($user_id, $group_id);
                if($learndash_is_user_in_group)
                        return true;
        }
        return false;
}
function llearndash_specific_is_user_in_group($user_id, $group_id) {
        return get_user_meta($user_id, "learndash_group_users_".$group_id, true);
}
